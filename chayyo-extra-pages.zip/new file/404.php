<section class="t_header">
    <?php include('header.php'); ?>
</section>
<section class="ch_page error_page p-tb50">
    <div class="ch_wrapper">
		<div class="error_text">
            <h1>404!</h1>
            <p>Sorry! The Page Not Found</p>
            <span>Oops! The page you are looking for does not exit. it might been moved or deleted.</span>
            <div class="return_home">
            	<a class="btn_fill_green" href="index.php">Return to Home</a>
            </div>
        </div>
    </div>
</section>

<?php include('footer.php'); ?>